#! /bin/bash
#echo 'Введите произвольное количество чисел'
#read A
for A in $*
do echo $A
done
