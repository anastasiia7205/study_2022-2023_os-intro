#! /bin/bash
tar -cvf ~/backup/progr1.tar progr1.sh

